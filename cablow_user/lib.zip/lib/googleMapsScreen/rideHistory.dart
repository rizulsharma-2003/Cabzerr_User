import 'package:cablow_user/googleMapsScreen/rideHistoryBloc/ride_history_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Ridehistory extends StatefulWidget {
  const Ridehistory({super.key});

  @override
  State<Ridehistory> createState() => _RidehistoryState();
}

class _RidehistoryState extends State<Ridehistory> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
      RideHistoryBloc()
        ..add(FetchRideHistoryEvent()),
      child: Scaffold(
        body: BlocBuilder<RideHistoryBloc, RideHistoryState>(
          builder: (context, state) {
            if(state is RideHistorySuccess){
              final data = state.historyData;
              print(data);
              return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Icon(Icons.location_on),
                      title: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('From - ${data[index]['source_address']}'),
                          Text('To - ${data[index]['destination_address']}'),
                        ],
                      ),
                      // subtitle: Text(
                      //     'Budh Vihar Phase II, Budh Vihar, Delhi'),
                      trailing: Icon(Icons.favorite_border),
                      onTap: () {
                        // Handle tap on destination
                      },
                    );
                  });
            }
            return SizedBox();
          },
        ),
      ),
    );
  }
}
