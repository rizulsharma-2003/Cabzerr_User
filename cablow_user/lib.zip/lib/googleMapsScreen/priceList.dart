import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_maps_flutter_platform_interface/src/types/location.dart';

import '../SharedPrefUtils.dart';
import '../bookrideBloc/book_ride_bloc.dart';
import '../bookrideBloc/get_driver_info_bloc.dart';
import '../bookrideBloc/get_driver_info_event.dart';
import '../bookrideBloc/get_driver_info_state.dart';

class Pricelist extends StatefulWidget {
  final double bikeFare;
  final double autoFare;
  final double miniFare;
  final double sedanFare;
  final double suvFare;
  final LatLng location;
  final LatLng currentLocation;
  final String? from;
  final String? to;

  const Pricelist({
    Key? key,
    required this.bikeFare,
    required this.autoFare,
    required this.miniFare,
    required this.sedanFare,
    required this.suvFare,
    required this.location,
    required this.currentLocation,
    this.from,
    this.to,
  }) : super(key: key);

  @override
  State<Pricelist> createState() => _PricelistState();
}

class _PricelistState extends State<Pricelist> {
  String? selectedPrice;
  String buttonText = 'Book Ride';
  late StreamController<void> _controller;
  Timer? _timer;

  void _updateSelectedPrice(String price, String rideType) {
    setState(() {
      selectedPrice = price;
      buttonText = 'Book $rideType';
    });
  }

  @override
  void initState() {
    super.initState();
    _controller = StreamController<void>();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.close();
    super.dispose();
  }

  void _showDetailsDialog(BuildContext context, String title, String imageAsset, String description) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.all(16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                imageAsset,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 8),
              Text(
                description,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundImage: AssetImage('assets/image/profile.png'),
                  ),
                  SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Farshid Darvishi',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.green, size: 16),
                          Text('4.8'),
                        ],
                      ),
                    ],
                  ),
                  Spacer(),
                  Icon(Icons.phone),
                ],
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'GeorgeTown',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text('1.5 mi, 30min'),
                    ],
                  ),
                  Spacer(),
                  Text(
                    '\$43.02',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text('Dismiss'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop(); // Accept button action
                    },
                    child: Row(
                      children: [
                        Text('Accept'),
                        Icon(Icons.arrow_forward),
                      ],
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _startDriverInfoPolling(BuildContext context) {
    _timer = Timer.periodic(Duration(seconds: 5), (timer) async {
      SharedPreferences sp = await SharedPreferences.getInstance();
      context.read<DriverInfoBloc>().add(
        GetDriverInfoEvent(
          userId: sp.getString(SharedPreffUtils().userIdKey)!,
          datetime: DateTime.now().toString(), rideId: '',
        ),
      );
      _controller.add(null); // Trigger StreamBuilder rebuild
    });
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<BookRideBloc>(
          create: (context) => BookRideBloc(),
        ),
        BlocProvider<DriverInfoBloc>(
          create: (context) => DriverInfoBloc(),
        ),
      ],
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildPriceTile(
                context,
                icon: Icons.motorcycle,
                title: 'Bike',
                subtitle: 'Affordable and Fast',
                price: '₹${widget.bikeFare.toStringAsFixed(2)}',
                rideType: 'Bike',
                imageAsset: 'assets/image/BMW.png',
                description: 'Bike rides are designed for quick and efficient travel, especially in urban areas. Ideal for short distances and solo travelers.',
              ),
              _buildPriceTile(
                context,
                icon: Icons.directions_car,
                title: 'Mini',
                subtitle: 'Economical Car',
                price: '₹${widget.miniFare.toStringAsFixed(2)}',
                rideType: 'Mini',
                imageAsset: 'assets/image/mini.png',
                description: 'Mini cars are budget-friendly and suitable for city commutes or short distances, offering comfort for up to four passengers.',
              ),
              _buildPriceTile(
                context,
                icon: Icons.local_taxi,
                title: 'Sedan',
                subtitle: 'Premium Car',
                price: '₹${widget.sedanFare.toStringAsFixed(2)}',
                oldPrice: '₹369',
                rideType: 'Sedan',
                imageAsset: 'assets/image/tesla.png',
                description: 'Sedans offer a blend of comfort and luxury with spacious interiors, making them ideal for longer trips and business travelers.',
              ),
              _buildPriceTile(
                context,
                icon: Icons.local_taxi_outlined,
                title: 'SUV',
                subtitle: '7 Seater Spacious',
                price: '₹${widget.suvFare.toStringAsFixed(2)}',
                oldPrice: '₹424',
                rideType: 'SUV',
                imageAsset: 'assets/image/Endevour.png',
                description: 'SUVs are perfect for larger groups or long journeys, offering ample space and comfort with powerful engines.',
              ),
              _buildPriceTile(
                context,
                icon: Icons.local_taxi_outlined,
                title: 'Auto',
                subtitle: 'Drop 5:06 pm',
                price: 'Coming Soon',
                oldPrice: 'Coming Soon',
                rideType: '',
                imageAsset: 'assets/image/Rickshaw.png',
                description: 'Auto rides are coming soon!',
              ),
              SizedBox(height: 16),
              Center(
                child: StreamBuilder<void>(
                  stream: _controller.stream,
                  builder: (context, snapshot) {
                    return ElevatedButton(
                      onPressed: selectedPrice != null
                          ? () async {
                        _showBottomSheet(context);
                        SharedPreferences sp = await SharedPreferences.getInstance();
                        context.read<BookRideBloc>().add(
                          SendBookRideDetailsEvent(
                            rideId: sp.getString(SharedPreffUtils().userIdKey),
                            destinationlatitude: widget.location.latitude,
                            sourcelatitude: widget.currentLocation.latitude,
                            destinationLongitudex: widget.location.longitude,
                            sourceaddress: widget.from ?? '',
                            sourceLongitudex: widget.currentLocation.longitude,
                            destinationaddress: widget.to ?? '',
                          ),
                        );
                        _startDriverInfoPolling(context);
                      }
                          : null,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(buttonText, style: TextStyle(fontSize: 16)),
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        backgroundColor: Colors.amber,
                        foregroundColor: Colors.black,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPriceTile(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String subtitle,
        required String price,
        String? oldPrice,
        required String rideType,
        required String imageAsset,
        required String description,
      }) {
    return GestureDetector(
      onTap: () {
        _updateSelectedPrice(price, rideType);
        _showDetailsDialog(context, title, imageAsset, description);
      },
      child: ListTile(
        leading: Icon(icon, size: 32),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (oldPrice != null)
              Text(
                oldPrice,
                style: TextStyle(
                  decoration: TextDecoration.lineThrough,
                  color: Colors.grey,
                ),
              ),
            Text(
              price,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
