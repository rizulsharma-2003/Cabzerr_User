part of 'ride_history_bloc.dart';

@immutable
sealed class RideHistoryEvent {}
 class FetchRideHistoryEvent extends RideHistoryEvent {
}
