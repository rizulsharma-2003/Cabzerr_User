import 'dart:ui';

final appcolor=Color(0xff613EEA);
final lightappcolor=Color(0xffECF0FD);