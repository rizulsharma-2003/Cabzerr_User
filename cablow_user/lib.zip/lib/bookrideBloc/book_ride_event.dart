part of 'book_ride_bloc.dart';

@immutable
sealed class BookRideEvent {}
 class SendBookRideDetailsEvent extends BookRideEvent{
  final rideId;
  final sourceaddress;
  final sourcelatitude;
  final sourceLongitudex;
  final destinationaddress;
  final destinationlatitude;
  final destinationLongitudex;
  SendBookRideDetailsEvent( {required this.rideId,required this.destinationlatitude ,required this.sourcelatitude,required this.destinationLongitudex,required this.sourceaddress,required this.sourceLongitudex,required this.destinationaddress});

}
