class SharedPreffUtils{
  String apiTokenKey = 'barrier_token';
  String isLoggedin = 'isLogin';
  String userIdKey = 'user_id';
  String firstNameKey = 'first_name';
  String lastNameKey = 'last_name';
  String emailKey = 'email';
  String mobileNumberKey = 'mobile_number';
  String otpKey = 'otp';
  String otpExpiryKey = 'otp_expiry';
  String deviceIdKey = 'device_id';
  String addressID = 'AddressID';
  String address = 'address';
  String selectedMobileNOForDelivery = 'selectedMobileNOForDelivery';
}